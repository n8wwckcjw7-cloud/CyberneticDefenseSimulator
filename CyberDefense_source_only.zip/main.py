from __future__ import annotations

import argparse
import subprocess
import sys
import threading
import time
from typing import Dict, List
import math
import random

import pygame
import qrcode

from Snake import Snake
from Jester import Jester
from Ghost import Ghost
from Sniper import Sniper
from Heavy_Arms import HeavyArms
from sim_core import simulate
from adversary_alpha import profile as alpha_profile
from adversary_beta import profile as beta_profile
from adversary_charlie import profile as charlie_profile


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Non-violent cyber defense simulation.")
    parser.add_argument("--seed", type=int, default=None, help="Random seed for reproducibility.")
    parser.add_argument("--max-steps", type=int, default=None, help="Safety cap for steps.")
    parser.add_argument("--fps", type=float, default=8.0, help="Frames per second.")
    parser.add_argument("--no-ansi", action="store_true", help="Disable ANSI colors/clear screen.")
    parser.add_argument("--no-stats-window", action="store_true", help="Disable stats window.")
    parser.add_argument("--cli", action="store_true", help="Run console-only mode.")
    return parser


class CyberDefenseUI:
    def __init__(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        pygame.display.set_caption("Cybernetics Defense Grid")
        self.clock = pygame.time.Clock()
        self.payload: Dict[str, object] = {}
        self.paused = False
        self.font_title = pygame.font.SysFont("Consolas", 20, bold=True)
        self.font_text = pygame.font.SysFont("Consolas", 14)
        self.font_small = pygame.font.SysFont("Consolas", 12)
        self.last_outcome = "none"
        self.popup_active = False
        self.fireworks: List[Dict[str, float]] = []
        self.intel_popup_until = 0.0
        self.intel_lines: List[str] = []
        self.intel_color = (120, 220, 255)
        self.intel_popup_active = False
        self.bank_popup_active = False
        self.bank_popup_title = ""
        self.bank_popup_detail = ""
        self.bank_item_rects: List[Dict[str, object]] = []
        self.intel_button_rect = pygame.Rect(0, 0, 0, 0)
        self.bank_button_rect = pygame.Rect(0, 0, 0, 0)
        self.intel_close_rect = pygame.Rect(0, 0, 0, 0)
        self.bank_close_rect = pygame.Rect(0, 0, 0, 0)
        self.donate_popup_active = False
        self.donate_button_rect = pygame.Rect(0, 0, 0, 0)
        self.donate_close_rect = pygame.Rect(0, 0, 0, 0)
        self.donate_address = "bc1q4s5z7767wrqs0mracslng4dqnsja8yg5qkznn7"
        self.donate_qr_surface = self._build_qr_surface(self.donate_address)
        self.last_donate_prompt = 0.0

    def toggle_pause(self) -> None:
        self.paused = not self.paused

    def update_payload(self, payload: Dict[str, object]) -> None:
        self.payload = payload
        outcome = str(payload.get("last_outcome", "none"))
        if outcome != "none" and outcome != self.last_outcome:
            self.last_outcome = outcome
            self.popup_active = True
            self.fireworks = self._spawn_fireworks()
        intel = payload.get("intel_popup", [])
        if isinstance(intel, list) and intel:
            self.intel_lines = [str(line) for line in intel][:3]
            if not self.intel_popup_active:
                self.intel_popup_active = True
                self.intel_color = random.choice([(120, 220, 255), (200, 255, 140), (255, 180, 120)])

    def _spawn_fireworks(self) -> List[Dict[str, float]]:
        width, height = self.screen.get_size()
        particles: List[Dict[str, float]] = []
        for _ in range(120):
            angle = random.uniform(0, 6.28)
            speed = random.uniform(1.5, 5.5)
            particles.append(
                {
                    "x": width / 2,
                    "y": height / 2,
                    "vx": speed * math.cos(angle),
                    "vy": speed * math.sin(angle),
                    "life": random.uniform(0.8, 1.6),
                }
            )
        return particles

    def _build_qr_surface(self, text: str) -> pygame.Surface:
        qr = qrcode.QRCode(border=1, box_size=2)
        qr.add_data(text)
        qr.make(fit=True)
        img = qr.make_image(fill_color="white", back_color="black")
        mode = img.mode
        size = img.size
        data = img.tobytes()
        return pygame.image.fromstring(data, size, mode)

    def _draw_camouflage(self) -> None:
        width, height = self.screen.get_size()
        colors = [(10, 30, 10), (20, 50, 20), (30, 60, 30), (15, 25, 10), (40, 40, 30)]
        for y in range(0, height, 24):
            for x in range(0, width, 36):
                color = colors[(x + y) % len(colors)]
                pygame.draw.rect(self.screen, color, (x, y, 36, 24))

    def _draw_fireworks(self) -> None:
        now = time.time()
        for p in list(self.fireworks):
            p["x"] += p["vx"]
            p["y"] += p["vy"]
            p["vy"] += 0.02
            p["life"] -= 0.02
            color = (255, 120, 120) if p["life"] < 0.5 else (255, 220, 120)
            pygame.draw.circle(self.screen, color, (int(p["x"]), int(p["y"])), 2)
            if p["life"] <= 0:
                self.fireworks.remove(p)

    def draw_text_block(self, text: str, x: int, y: int, color, font, max_width: int) -> int:
        for line in text.splitlines():
            clipped = self._clip_text(line, font, max_width)
            surface = font.render(clipped, True, color)
            self.screen.blit(surface, (x, y))
            y += surface.get_height() + 2
        return y

    def _clip_text(self, text: str, font, max_width: int) -> str:
        if font.size(text)[0] <= max_width:
            return text
        clipped = text
        while clipped and font.size(clipped + "...")[0] > max_width:
            clipped = clipped[:-1]
        return clipped + "..."

    def run(self) -> None:
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        return
                    if event.key == pygame.K_SPACE:
                        if self.popup_active:
                            self.popup_active = False
                        else:
                            self.toggle_pause()
                    if event.key == pygame.K_RETURN and self.popup_active:
                        self.popup_active = False
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    mx, my = event.pos
                    if self.intel_popup_active:
                        if self._button_hit(mx, my, self.intel_close_rect):
                            self.intel_popup_active = False
                    elif self.bank_popup_active:
                        if self._button_hit(mx, my, self.bank_close_rect):
                            self.bank_popup_active = False
                    elif self.donate_popup_active:
                        if self._button_hit(mx, my, self.donate_close_rect):
                            self.donate_popup_active = False
                    else:
                        for item in self.bank_item_rects:
                            rect = item["rect"]
                            if rect.collidepoint(mx, my):
                                self.bank_popup_title = str(item["title"])
                                self.bank_popup_detail = str(item["detail"])
                                self.bank_popup_active = True
                                break

            width, height = self.screen.get_size()
            self.screen.fill((0, 0, 0))

            # Background grid
            for x in range(0, width, 48):
                pygame.draw.line(self.screen, (10, 20, 10), (x, 0), (x, height))
            for y in range(0, height, 36):
                pygame.draw.line(self.screen, (10, 20, 10), (0, y), (width, y))

            if not self.payload:
                text = self.font_title.render("INITIALIZING DEFENSE GRID...", True, (60, 255, 120))
                self.screen.blit(text, (width // 2 - text.get_width() // 2, height // 2))
                pygame.display.flip()
                self.clock.tick(30)
                continue

            map_text = str(self.payload.get("map", ""))
            dash_text = str(self.payload.get("dashboard", ""))
            comms = self.payload.get("comms", [])
            safe_metrics = self.payload.get("safe_metrics", {})
            bases = self.payload.get("bases", {})
            adversaries = self.payload.get("adversaries", [])
            tiers = self.payload.get("tiers", {})
            budget = self.payload.get("budget", 0.0)
            funds = self.payload.get("funds", 0.0)
            gsj_credits = self.payload.get("gsj_credits", 0.0)
            bank = self.payload.get("bank", [])

            left_w = int(width * 0.70)
            right_w = max(360, width - left_w - 20)

            # Map panel
            pygame.draw.rect(self.screen, (26, 255, 90), (10, 10, left_w, height - 20), 2)
            self.screen.blit(self.font_title.render("CYBERNETICS DEFENSE MAP", True, (26, 255, 90)), (20, 20))
            self.draw_text_block(map_text, 20, 60, (26, 255, 90), self.font_text, left_w - 40)

            # Right panel
            rx0 = left_w + 20
            pygame.draw.rect(self.screen, (26, 255, 90), (rx0, 10, right_w, height - 20), 2)
            self.screen.blit(self.font_title.render("SYSTEM TELEMETRY", True, (26, 255, 90)), (rx0 + 10, 20))
            y_cursor = self.draw_text_block(dash_text, rx0 + 10, 60, (168, 255, 209), self.font_small, right_w - 20)

            adv_y = y_cursor + 18
            self.screen.blit(self.font_title.render("ADVERSARY STRATEGY", True, (255, 60, 60)), (rx0 + 10, adv_y))
            adv_lines = "\n".join([f"{item['name']}: {item['flavor']}" for item in adversaries])
            y_cursor = self.draw_text_block(adv_lines, rx0 + 10, adv_y + 30, (255, 110, 110), self.font_small, right_w - 20)

            tier_line = (
                f"TIERS ADV:{tiers.get('adversary', 1)} RESP:{tiers.get('response', 1)} "
                f"BUDGET:{budget:5.1f} FUNDS:{funds:6.1f} GSJ:{gsj_credits:6.1f}"
            )
            self.draw_text_block(tier_line, rx0 + 10, y_cursor + 10, (255, 110, 110), self.font_small, right_w - 20)
            y_cursor += 28

            sm_y = y_cursor + 18
            self.screen.blit(self.font_title.render("SAFE METRICS", True, (26, 255, 90)), (rx0 + 10, sm_y))
            sm_lines = "\n".join(
                [
                    f"Containments: {safe_metrics.get('containments', 0)}",
                    f"Recoveries:   {safe_metrics.get('recoveries', 0)}",
                    f"Blocked:      {safe_metrics.get('blocked', 0)}",
                    f"Assets Sec:   {safe_metrics.get('assets_secured', 0)}",
                    f"Intel Rec:    {safe_metrics.get('intel_recovered', 0)}",
                ]
            )
            y_cursor = self.draw_text_block(sm_lines, rx0 + 10, sm_y + 30, (168, 255, 209), self.font_small, right_w - 20)

            base_y = y_cursor + 18
            self.screen.blit(self.font_title.render("BASE INTEGRITY", True, (26, 255, 90)), (rx0 + 10, base_y))
            y_cursor = base_y + 28
            for name, value in bases.items():
                label = self.font_small.render(name, True, (168, 255, 209))
                self.screen.blit(label, (rx0 + 10, y_cursor))
                bar_w = int((right_w - 120) * (float(value) / 100.0))
                pygame.draw.rect(self.screen, (26, 255, 90), (rx0 + 110, y_cursor + 4, bar_w, 8))
                y_cursor += 20

            bank_y = y_cursor + 18
            self.screen.blit(self.font_title.render("INTEL BANK", True, (26, 255, 90)), (rx0 + 10, bank_y))
            self.bank_item_rects = []
            y_cursor = bank_y + 28
            for item in bank[-5:]:
                title = str(item.get("title", "entry"))
                rect = pygame.Rect(rx0 + 10, y_cursor, right_w - 20, 18)
                self.bank_item_rects.append({"rect": rect, "title": title, "detail": str(item.get("detail", ""))})
                pygame.draw.rect(self.screen, (20, 40, 20), rect)
                pygame.draw.rect(self.screen, (26, 255, 90), rect, 1)
                title = self._clip_text(title, self.font_small, right_w - 24)
                self.screen.blit(self.font_small.render(title, True, (168, 255, 209)), (rx0 + 14, y_cursor + 2))
                y_cursor += 22

            comms_y = max(y_cursor + 12, height - 210)
            self.screen.blit(self.font_title.render("COMMS (DECRYPTED)", True, (26, 255, 90)), (rx0 + 10, comms_y))
            comms_text = "\n".join(comms[-6:]) if isinstance(comms, list) else str(comms)
            self.draw_text_block(comms_text, rx0 + 10, comms_y + 30, (168, 255, 209), self.font_small, right_w - 20)

            legend = "S/J/G/R/M agents  P spy  X/Y/Z adversary  V vault  B base  o node  C cache  I intel  * plume  : patrol"
            self.screen.blit(self.font_small.render(legend, True, (26, 255, 90)), (20, height - 24))

            if self.paused:
                overlay = pygame.Surface((width, height))
                overlay.set_alpha(220)
                overlay.fill((0, 0, 0))
                self.screen.blit(overlay, (0, 0))
                pause_text = self.font_title.render("PAUSED - PRESS SPACE TO RESUME", True, (26, 255, 90))
                self.screen.blit(pause_text, (width // 2 - pause_text.get_width() // 2, height // 2))

            if self.popup_active:
                self._draw_camouflage()
                self._draw_fireworks()
                label = "VICTOR: DEFENDERS" if "defenders win" in self.last_outcome else "VICTOR: ADVERSARY"
                text = self.font_title.render(label, True, (255, 255, 255))
                sub = self.font_text.render("PRESS SPACE OR ENTER TO PLAY AGAIN", True, (255, 220, 120))
                self.screen.blit(text, (width // 2 - text.get_width() // 2, height // 2 - 20))
                self.screen.blit(sub, (width // 2 - sub.get_width() // 2, height // 2 + 12))

            if not self.popup_active and not self.donate_popup_active:
                if time.time() - self.last_donate_prompt > 45:
                    self.donate_popup_active = True
                    self.last_donate_prompt = time.time()

            if self.intel_popup_active:
                popup_w = int(width * 0.52)
                popup_h = 120
                px = (width - popup_w) // 2
                py = 40
                pygame.draw.rect(self.screen, (0, 0, 0), (px, py, popup_w, popup_h))
                pygame.draw.rect(self.screen, self.intel_color, (px, py, popup_w, popup_h), 2)
                self.screen.blit(self.font_title.render("INTEL PULSE", True, self.intel_color), (px + 12, py + 10))
                self.intel_close_rect = self._draw_close(px, py)
                y = py + 40
                for line in self.intel_lines:
                    line = self._clip_text(line, self.font_small, popup_w - 24)
                    self.screen.blit(self.font_small.render(line, True, self.intel_color), (px + 12, y))
                    y += 18
                self.intel_button_rect = pygame.Rect(0, 0, 0, 0)

            if self.bank_popup_active:
                popup_w = int(width * 0.56)
                popup_h = 160
                px = (width - popup_w) // 2
                py = 80
                pygame.draw.rect(self.screen, (0, 0, 0), (px, py, popup_w, popup_h))
                pygame.draw.rect(self.screen, (200, 255, 140), (px, py, popup_w, popup_h), 2)
                self.screen.blit(self.font_title.render(self.bank_popup_title, True, (200, 255, 140)), (px + 12, py + 10))
                self.bank_close_rect = self._draw_close(px, py)
                y = py + 40
                for line in self.bank_popup_detail.split(" | "):
                    line = self._clip_text(line, self.font_small, popup_w - 24)
                    self.screen.blit(self.font_small.render(line, True, (200, 255, 140)), (px + 12, y))
                    y += 18
                self.bank_button_rect = pygame.Rect(0, 0, 0, 0)

            if self.donate_popup_active:
                popup_w = int(width * 0.48)
                popup_h = 220
                px = (width - popup_w) // 2
                py = height - popup_h - 40
                pygame.draw.rect(self.screen, (0, 0, 0), (px, py, popup_w, popup_h))
                pygame.draw.rect(self.screen, (120, 220, 255), (px, py, popup_w, popup_h), 2)
                title = self.font_title.render("Support This Simulation", True, (120, 220, 255))
                self.screen.blit(title, (px + 12, py + 10))
                self.donate_close_rect = self._draw_close(px, py)
                sub = self.font_small.render("Donations help improve visuals and stability.", True, (168, 255, 209))
                self.screen.blit(sub, (px + 12, py + 36))
                addr = self.font_small.render(self.donate_address, True, (200, 255, 140))
                self.screen.blit(addr, (px + 12, py + 56))
                if self.donate_qr_surface:
                    qr = pygame.transform.scale(self.donate_qr_surface, (140, 140))
                    self.screen.blit(qr, (px + popup_w - 160, py + 50))
                self.donate_button_rect = pygame.Rect(0, 0, 0, 0)

            pygame.display.flip()
            self.clock.tick(30)

    def _draw_more_button(self, px: int, py: int, w: int, h: int) -> pygame.Rect:
        bx = px + w - 260
        by = py + h - 34
        bw = 240
        bh = 24
        pygame.draw.rect(self.screen, (40, 40, 40), (bx, by, bw, bh))
        pygame.draw.rect(self.screen, (120, 220, 255), (bx, by, bw, bh), 1)
        label = self.font_small.render("DO YOU WANT TO KNOW MORE", True, (120, 220, 255))
        self.screen.blit(label, (bx + 8, by + 4))
        return pygame.Rect(bx, by, bw, bh)

    def _draw_close(self, px: int, py: int) -> pygame.Rect:
        rect = pygame.Rect(px + 8, py + 8, 18, 18)
        pygame.draw.rect(self.screen, (40, 40, 40), rect)
        pygame.draw.rect(self.screen, (200, 60, 60), rect, 1)
        label = self.font_small.render("X", True, (200, 60, 60))
        self.screen.blit(label, (rect.x + 4, rect.y + 1))
        return rect

    def _button_hit(self, mx: int, my: int, rect: pygame.Rect) -> bool:
        return rect.collidepoint(mx, my)

    def _intel_button_rect_for(self, width: int) -> pygame.Rect:
        popup_w = int(width * 0.52)
        popup_h = 120
        px = (width - popup_w) // 2
        py = 40
        bx = px + popup_w - 260
        by = py + popup_h - 34
        return pygame.Rect(bx, by, 240, 24)

    def _bank_button_rect_for(self, width: int) -> pygame.Rect:
        popup_w = int(width * 0.56)
        popup_h = 160
        px = (width - popup_w) // 2
        py = 80
        bx = px + popup_w - 260
        by = py + popup_h - 34
        return pygame.Rect(bx, by, 240, 24)

    def _donate_button_rect_for(self, width: int) -> pygame.Rect:
        popup_w = int(width * 0.48)
        popup_h = 220
        px = (width - popup_w) // 2
        py = self.screen.get_height() - popup_h - 40
        bx = px + popup_w - 260
        by = py + popup_h - 34
        return pygame.Rect(bx, by, 240, 24)


def main() -> None:
    args = build_parser().parse_args()

    if args.cli:
        if not args.no_stats_window:
            try:
                subprocess.Popen(
                    [sys.executable, "stats_viewer.py"],
                    creationflags=subprocess.CREATE_NEW_CONSOLE,
                )
            except Exception:
                pass
        agents = [Snake(), Jester(), Ghost(), Sniper(), HeavyArms()]
        adversaries = [alpha_profile(), beta_profile(), charlie_profile()]
        simulate(
            agents=agents,
            adversaries=adversaries,
            steps=args.max_steps,
            seed=args.seed,
            fps=args.fps,
            ansi=not args.no_ansi,
        )
        return

    ui = CyberDefenseUI()

    agents = [Snake(), Jester(), Ghost(), Sniper(), HeavyArms()]
    adversaries = [alpha_profile(), beta_profile(), charlie_profile()]

    def worker() -> None:
        simulate(
            agents=agents,
            adversaries=adversaries,
            steps=args.max_steps,
            seed=args.seed,
            fps=args.fps,
            ansi=False,
            render_console=False,
            step_callback=ui.update_payload,
            pause_check=lambda: ui.paused or ui.popup_active,
            map_override=(120, 32),
        )

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    ui.run()


if __name__ == "__main__":
    main()
