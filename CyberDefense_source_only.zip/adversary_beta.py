from __future__ import annotations

from sim_core import AdversaryProfile, ThreatSignature


def profile() -> AdversaryProfile:
    return AdversaryProfile(
        name="adversary_beta",
        flavor="high-pressure disruption",
        pressure_bias=0.7,
        signatures=[
            ThreatSignature("ransom-pressure", 22, 26, 24, 18),
            ThreatSignature("supply-chain-noise", 19, 24, 18, 22),
            ThreatSignature("edge-flood", 17, 18, 28, 14),
        ],
    )
