from __future__ import annotations

from sim_core import AdversaryProfile, ThreatSignature


def profile() -> AdversaryProfile:
    return AdversaryProfile(
        name="adversary_alpha",
        flavor="stealth-first intrusion",
        pressure_bias=0.6,
        signatures=[
            ThreatSignature("credential-harvest", 18, 22, 14, 32),
            ThreatSignature("living-off-the-land", 16, 20, 10, 36),
            ThreatSignature("stealth-pivot", 20, 18, 16, 34),
        ],
    )
