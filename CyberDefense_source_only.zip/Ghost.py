from __future__ import annotations

from typing import List
import random

from sim_core import Agent, Event, IncidentState


class Ghost(Agent):
    def __init__(self) -> None:
        super().__init__(
            name="Ghost",
            specialty="forensics-containment",
            skills=[
                "rapid-isolation",
                "memory-forensics",
                "restoration-burst",
                "vault-hardening",
            ],
        )

    def act(self, state: IncidentState, rng: random.Random) -> List[Event]:
        events: List[Event] = []

        if self._ready("rapid-isolation") and state.adversary_momentum > 20:
            impact = {
                "containment_level": 6.0 + rng.uniform(0.0, 2.0),
                "service_availability": -1.5,
                "data_exposure_risk": -2.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="rapid-isolation",
                    impact=impact,
                    notes="isolated infected segments",
                )
            )
            self.cooldowns["rapid-isolation"] = 2

        if self._ready("memory-forensics"):
            impact = {
                "detection_confidence": 4.5 + rng.uniform(0.0, 2.5),
                "containment_level": 2.0,
                "adversary_momentum": -1.5,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="memory-forensics",
                    impact=impact,
                    notes="volatile artifacts collected",
                )
            )
            self.cooldowns["memory-forensics"] = 2

        if self._ready("restoration-burst") and state.network_integrity < 85:
            impact = {
                "network_integrity": 5.5,
                "service_availability": 3.0,
                "fatigue": 1.2,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="restoration-burst",
                    impact=impact,
                    notes="rollbacks + rapid patching",
                )
            )
            self.cooldowns["restoration-burst"] = 3

        if self._ready("vault-hardening") and state.vault_security < 85:
            impact = {
                "vault_security": 5.5 + rng.uniform(0.0, 1.5),
                "containment_level": 2.0,
                "data_exposure_risk": -1.5,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="vault-hardening",
                    impact=impact,
                    notes="critical asset shield reinforced",
                )
            )
            self.cooldowns["vault-hardening"] = 3

        return events
