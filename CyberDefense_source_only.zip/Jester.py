from __future__ import annotations

from typing import List
import random

from sim_core import Agent, Event, IncidentState


class Jester(Agent):
    def __init__(self) -> None:
        super().__init__(
            name="Jester",
            specialty="deception-ops",
            skills=[
                "honeypot-weave",
                "traffic-misdirection",
                "canary-network",
                "authenticator-rotation",
            ],
        )

    def act(self, state: IncidentState, rng: random.Random) -> List[Event]:
        events: List[Event] = []

        if self._ready("honeypot-weave"):
            impact = {
                "detection_confidence": 4.0 + rng.uniform(0.0, 2.5),
                "containment_level": 3.5,
                "adversary_momentum": -2.5,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="honeypot-weave",
                    impact=impact,
                    notes="decoys captured probes",
                )
            )
            self.cooldowns["honeypot-weave"] = 2

        if self._ready("traffic-misdirection"):
            impact = {
                "service_availability": 2.5,
                "containment_level": 3.0,
                "data_exposure_risk": -1.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="traffic-misdirection",
                    impact=impact,
                    notes="rerouted high-risk flows",
                )
            )
            self.cooldowns["traffic-misdirection"] = 3

        if self._ready("canary-network") and state.detection_confidence < 75:
            impact = {
                "detection_confidence": 6.0,
                "adversary_momentum": -1.5,
                "fatigue": 0.8,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="canary-network",
                    impact=impact,
                    notes="canary tokens tripped",
                )
            )
            self.cooldowns["canary-network"] = 3

        if self._ready("authenticator-rotation") and state.vault_security < 80:
            impact = {
                "vault_security": 6.0 + rng.uniform(0.0, 2.0),
                "internal_integrity": 2.0,
                "containment_level": 1.5,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="authenticator-rotation",
                    impact=impact,
                    notes="trusted token rotation + lock reset",
                )
            )
            self.cooldowns["authenticator-rotation"] = 3

        return events
