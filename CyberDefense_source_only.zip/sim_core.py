from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Tuple
import os
import random
import time
import shutil
import msvcrt


ANSI_CLEAR = "\x1b[2J\x1b[H"
ANSI_RESET = "\x1b[0m"
ANSI_BLACK_BG = "\x1b[40m"
ANSI_GREEN = "\x1b[32m"
ANSI_RED = "\x1b[31m"
ANSI_DIM = "\x1b[2m"
ANSI_BOLD = "\x1b[1m"


def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


@dataclass
class ThreatSignature:
    vector: str
    base_severity: int
    persistence: int
    spread: int
    stealth: int


@dataclass
class AdversaryProfile:
    name: str
    flavor: str
    pressure_bias: float
    signatures: List[ThreatSignature]


@dataclass
class Threat:
    actor: str
    vector: str
    severity: int
    persistence: int
    spread: int
    stealth: int


@dataclass
class Event:
    t: int
    actor: str
    action: str
    impact: Dict[str, float] = field(default_factory=dict)
    notes: str = ""


@dataclass
class IncidentState:
    time_step: int = 0
    network_integrity: float = 90.0
    detection_confidence: float = 30.0
    containment_level: float = 20.0
    service_availability: float = 95.0
    data_exposure_risk: float = 25.0
    adversary_momentum: float = 40.0
    fatigue: float = 0.0
    model_level: float = 15.0
    internal_integrity: float = 88.0
    vault_security: float = 70.0
    trace: Dict[str, List[Tuple[int, int]]] = field(default_factory=dict)
    positions: Dict[str, Tuple[int, int]] = field(default_factory=dict)
    comms_buffer: List[str] = field(default_factory=list)
    base_integrity: Dict[str, float] = field(default_factory=dict)
    terrain: List[List[str]] = field(default_factory=list)
    terrain_size: Tuple[int, int] = (0, 0)
    containments: int = 0
    recoveries: int = 0
    blocked: int = 0
    assets_secured: int = 0
    insider_threat_level: float = 15.0
    resource_budget: float = 100.0
    adversary_tier: int = 1
    response_tier: int = 1
    intel_points: List[Tuple[int, int]] = field(default_factory=list)
    revealed_intel: set = field(default_factory=set)
    node_points: List[Tuple[int, int]] = field(default_factory=list)
    cache_points: List[Tuple[int, int]] = field(default_factory=list)
    intel_recovered: int = 0
    latest_intel: List[str] = field(default_factory=list)
    bank_entries: List[Dict[str, str]] = field(default_factory=list)
    funds: float = 250.0
    gsj_credits: float = 120.0

    def apply(self, impact: Dict[str, float]) -> None:
        for key, delta in impact.items():
            current = getattr(self, key)
            setattr(self, key, clamp(current + delta))

    def snapshot(self) -> Dict[str, float]:
        return {
            "integrity": self.network_integrity,
            "detect": self.detection_confidence,
            "contain": self.containment_level,
            "service": self.service_availability,
            "exposure": self.data_exposure_risk,
            "momentum": self.adversary_momentum,
            "fatigue": self.fatigue,
            "model": self.model_level,
            "internal": self.internal_integrity,
            "vault": self.vault_security,
        }


class Agent:
    def __init__(self, name: str, specialty: str, skills: List[str]) -> None:
        self.name = name
        self.specialty = specialty
        self.skills = skills
        self.cooldowns: Dict[str, int] = {}

    def _tick(self) -> None:
        for key in list(self.cooldowns.keys()):
            self.cooldowns[key] = max(0, self.cooldowns[key] - 1)

    def _ready(self, skill: str) -> bool:
        return self.cooldowns.get(skill, 0) == 0

    def act(self, state: IncidentState, rng: random.Random) -> List[Event]:
        raise NotImplementedError


def encode_message(text: str) -> str:
    cipher = []
    for ch in text.upper():
        if ch.isalnum():
            cipher.append(str((ord(ch) * 7) % 97))
        elif ch == " ":
            cipher.append("~")
        else:
            cipher.append("@")
    return ".".join(cipher)


def ensure_log_dir() -> str:
    log_dir = os.path.join(os.getcwd(), "logs")
    os.makedirs(log_dir, exist_ok=True)
    return os.path.join(log_dir, "comms.log")


def write_comms_log(path: str, line: str) -> None:
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(line + "\n")


def write_winner_log(line: str) -> None:
    path = os.path.join(os.getcwd(), "logs", "winners.log")
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(line + "\n")


def write_stats_snapshot(state: IncidentState, epoch: int, wins: int, losses: int, last_outcome: str) -> None:
    path = os.path.join(os.getcwd(), "logs", "stats.json")
    data = {
        "epoch": epoch,
        "step": state.time_step,
        "integrity": state.network_integrity,
        "detect": state.detection_confidence,
        "contain": state.containment_level,
        "service": state.service_availability,
        "exposure": state.data_exposure_risk,
        "momentum": state.adversary_momentum,
        "fatigue": state.fatigue,
        "model": state.model_level,
        "internal": state.internal_integrity,
        "vault": state.vault_security,
        "bases": state.base_integrity,
        "last_outcome": last_outcome,
        "wins": wins,
        "losses": losses,
        "funds": state.funds,
        "gsj_credits": state.gsj_credits,
        "containments": getattr(state, "containments", 0),
        "recoveries": getattr(state, "recoveries", 0),
        "blocked": getattr(state, "blocked", 0),
        "assets_secured": getattr(state, "assets_secured", 0),
    }
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(__import__("json").dumps(data))


def generate_threat(
    state: IncidentState,
    rng: random.Random,
    profiles: Iterable[AdversaryProfile],
) -> Optional[Threat]:
    pressure = state.adversary_momentum / 100.0
    base_chance = 0.45 + pressure / 2
    if rng.random() > base_chance:
        return None

    profiles_list = list(profiles)
    profile = rng.choice(profiles_list)
    signature = rng.choice(profile.signatures)
    model_scaler = 1.0 + state.model_level / 120.0
    severity = int(signature.base_severity * model_scaler + rng.randint(0, 6))
    return Threat(
        actor=profile.name,
        vector=signature.vector,
        severity=severity,
        persistence=signature.persistence,
        spread=signature.spread,
        stealth=signature.stealth,
    )


def threat_impact(threat: Threat, rng: random.Random) -> Dict[str, float]:
    impact = {
        "network_integrity": -threat.severity * 0.22,
        "service_availability": -threat.spread * 0.28,
        "data_exposure_risk": threat.persistence * 0.38,
        "adversary_momentum": threat.severity * 0.3,
        "detection_confidence": -threat.stealth * 0.2,
        "internal_integrity": -threat.persistence * 0.12,
        "vault_security": -threat.spread * 0.1,
    }
    impact["network_integrity"] += rng.uniform(-1.2, 1.2)
    impact["service_availability"] += rng.uniform(-1.5, 1.0)
    return impact


def adjust_tiers(state: IncidentState) -> None:
    momentum = state.adversary_momentum
    exposure = state.data_exposure_risk
    if momentum > 75 or exposure > 70:
        state.adversary_tier = 3
    elif momentum > 50 or exposure > 50:
        state.adversary_tier = 2
    else:
        state.adversary_tier = 1

    if state.detection_confidence > 70 and state.containment_level > 65:
        state.response_tier = 3
    elif state.detection_confidence > 55:
        state.response_tier = 2
    else:
        state.response_tier = 1


def compute_resource_budget(state: IncidentState) -> None:
    pressure = state.adversary_momentum / 100.0
    base_budget = 90.0 + state.model_level * 0.6
    penalty = pressure * 40.0 + state.fatigue * 0.2
    state.resource_budget = clamp(base_budget - penalty, 20.0, 150.0)


def update_learning(state: IncidentState) -> None:
    learning_delta = 0.0
    if state.containment_level > 60:
        learning_delta += 1.2
    if state.detection_confidence > 55:
        learning_delta += 0.8
    if state.data_exposure_risk < 30:
        learning_delta += 0.6
    if state.fatigue > 75:
        learning_delta -= 0.8
    if state.insider_threat_level > 60:
        learning_delta += 0.4
    state.apply({"model_level": learning_delta})


def insider_threat_impact(state: IncidentState, rng: random.Random) -> Optional[Dict[str, float]]:
    pressure = state.insider_threat_level / 100.0
    if rng.random() > 0.65 + pressure / 2:
        return None
    return {
        "detection_confidence": -4.0 * (0.6 + pressure),
        "containment_level": -3.0 * (0.6 + pressure),
        "data_exposure_risk": 4.5 * (0.6 + pressure),
        "internal_integrity": -3.0 * (0.6 + pressure),
        "adversary_momentum": 3.5 * (0.6 + pressure),
    }


def smooth_field(field: List[List[float]]) -> List[List[float]]:
    height = len(field)
    width = len(field[0]) if height else 0
    out = [[0.0 for _ in range(width)] for _ in range(height)]
    for y in range(height):
        for x in range(width):
            total = 0.0
            count = 0
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    ny = y + dy
                    nx = x + dx
                    if 0 <= ny < height and 0 <= nx < width:
                        total += field[ny][nx]
                        count += 1
            out[y][x] = total / max(1, count)
    return out


def generate_terrain(width: int, height: int, rng: random.Random) -> List[List[str]]:
    field = [[rng.random() for _ in range(width)] for _ in range(height)]
    for _ in range(2):
        field = smooth_field(field)

    contour = " .,:;!|/*"
    terrain = [[" " for _ in range(width)] for _ in range(height)]

    for y in range(height):
        for x in range(width):
            idx = int(clamp(field[y][x] * 10, 0, 9))
            terrain[y][x] = contour[idx]

    for y in range(2, height - 2, 4):
        for x in range(width):
            if rng.random() < 0.35:
                terrain[y][x] = "-" if rng.random() < 0.6 else "="
    for x in range(4, width - 2, 8):
        for y in range(height):
            if rng.random() < 0.35:
                terrain[y][x] = "|" if rng.random() < 0.6 else "/"

    return terrain


def ensure_terrain(state: IncidentState, width: int, height: int, rng: random.Random) -> None:
    if state.terrain_size != (width, height):
        state.terrain = generate_terrain(width, height, rng)
        state.terrain_size = (width, height)


def ensure_assets(state: IncidentState, width: int, height: int, rng: random.Random) -> None:
    if not state.node_points or not state.cache_points or not state.intel_points:
        state.node_points = []
        state.cache_points = []
        state.intel_points = []
        state.revealed_intel = set()
        for _ in range(18):
            state.node_points.append((rng.randint(2, width - 3), rng.randint(2, height - 3)))
        for _ in range(8):
            state.cache_points.append((rng.randint(2, width - 3), rng.randint(2, height - 3)))
        for _ in range(6):
            state.intel_points.append((rng.randint(2, width - 3), rng.randint(2, height - 3)))

def move_agents(
    state: IncidentState,
    rng: random.Random,
    width: int,
    height: int,
    agent_names: Iterable[str],
    adversary_positions: Dict[str, Tuple[int, int]],
) -> None:
    for name in agent_names:
        x, y = state.positions.get(name, (rng.randint(1, width - 2), rng.randint(1, height - 2)))
        dx, dy = rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1), (0, 0)])
        if state.detection_confidence > 55 and adversary_positions:
            # Drift toward nearest adversary when signal is strong.
            ax, ay = min(
                adversary_positions.values(),
                key=lambda pos: abs(pos[0] - x) + abs(pos[1] - y),
            )
            dx = 1 if ax > x else -1 if ax < x else 0
            dy = 1 if ay > y else -1 if ay < y else 0
        nx = max(1, min(width - 2, x + dx))
        ny = max(1, min(height - 2, y + dy))
        state.positions[name] = (nx, ny)
        state.trace.setdefault(name, []).append((nx, ny))
        state.trace[name] = state.trace[name][-12:]


def render_map(
    state: IncidentState,
    width: int = 42,
    height: int = 12,
    ansi: bool = True,
    adversary_names: Optional[List[str]] = None,
) -> str:
    grid = [row[:] for row in state.terrain] if state.terrain else [[" " for _ in range(width)] for _ in range(height)]

    agent_markers = {
        "snake": "S",
        "jester": "J",
        "ghost": "G",
        "sniper": "R",
        "heavy_arms": "M",
        "spy": "P",
    }
    adv_markers: Dict[str, str] = {}
    if adversary_names:
        for idx, name in enumerate(adversary_names):
            adv_markers[name] = chr(ord("X") + idx)

    # Heatmap + patrol + nodes + caches
    for y in range(height):
        for x in range(width):
            if (x, y) in state.node_points:
                grid[y][x] = "o"
            if (x, y) in state.cache_points:
                grid[y][x] = "C"
            if (x, y) in state.revealed_intel:
                grid[y][x] = "I"

    for base_id, integrity in state.base_integrity.items():
        if base_id in state.positions:
            bx, by = state.positions[base_id]
            for dy in range(-3, 4):
                for dx in range(-3, 4):
                    if abs(dx) == 3 or abs(dy) == 3:
                        px = bx + dx
                        py = by + dy
                        if 0 <= px < width and 0 <= py < height and grid[py][px] == " ":
                            grid[py][px] = ":"

    for name, pos in state.positions.items():
        if name in adv_markers:
            ax, ay = pos
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    if abs(dx) + abs(dy) == 2:
                        px = ax + dx
                        py = ay + dy
                        if 0 <= px < width and 0 <= py < height and grid[py][px] == " ":
                            grid[py][px] = "*"

    for name, path in state.trace.items():
        for x, y in path:
            if 0 <= y < height and 0 <= x < width:
                grid[y][x] = "."
        if path:
            x, y = path[-1]
            if 0 <= y < height and 0 <= x < width:
                grid[y][x] = adv_markers.get(name, agent_markers.get(name, name[0].upper()))

    for base_id, integrity in state.base_integrity.items():
        if base_id in state.positions:
            x, y = state.positions[base_id]
            grid[y][x] = "B" if integrity > 50 else "b"

    if "vault" in state.positions:
        vx, vy = state.positions["vault"]
        grid[vy][vx] = "V"

    lines = []
    for row in grid:
        line = "".join(row)
        if ansi:
            line = (
                line.replace("S", ANSI_BOLD + ANSI_GREEN + "S" + ANSI_RESET)
                .replace("J", ANSI_BOLD + ANSI_GREEN + "J" + ANSI_RESET)
                .replace("G", ANSI_BOLD + ANSI_GREEN + "G" + ANSI_RESET)
                .replace("R", ANSI_BOLD + ANSI_GREEN + "R" + ANSI_RESET)
                .replace("M", ANSI_BOLD + ANSI_GREEN + "M" + ANSI_RESET)
                .replace("B", ANSI_BOLD + ANSI_GREEN + "B" + ANSI_RESET)
                .replace("b", ANSI_BOLD + ANSI_RED + "b" + ANSI_RESET)
                .replace("V", ANSI_BOLD + ANSI_GREEN + "V" + ANSI_RESET)
                .replace("o", ANSI_DIM + ANSI_GREEN + "o" + ANSI_RESET)
                .replace("C", ANSI_BOLD + ANSI_GREEN + "C" + ANSI_RESET)
                .replace("I", ANSI_BOLD + ANSI_GREEN + "I" + ANSI_RESET)
            )
            for adv in ["X", "Y", "Z"]:
                line = line.replace(adv, ANSI_BOLD + ANSI_RED + adv + ANSI_RESET)
            line = line.replace("P", ANSI_BOLD + ANSI_RED + "P" + ANSI_RESET)
        lines.append(line)
    return "\n".join(lines)


def render_dashboard(state: IncidentState) -> str:
    snap = state.snapshot()

    def bar(label: str, value: float) -> str:
        blocks = int(value / 4)
        fill = "|" * blocks
        rest = "/" * (25 - blocks)
        return f"{label:10} [{fill}{rest}] {value:5.1f}"

    def spark(values: List[float], width: int = 26) -> str:
        if not values:
            return "." * width
        levels = " .:-=+*#%@"
        window = values[-width:]
        line = ""
        for v in window:
            idx = int(clamp(v, 0, 100) / 10)
            idx = min(idx, len(levels) - 1)
            line += levels[idx]
        return line

    lines = [
        f"Step {state.time_step:06d} | Model {state.model_level:5.1f}",
        bar("Integrity", snap["integrity"]),
        bar("Detect", snap["detect"]),
        bar("Contain", snap["contain"]),
        bar("Service", snap["service"]),
        bar("Exposure", snap["exposure"]),
        bar("Momentum", snap["momentum"]),
        bar("Fatigue", snap["fatigue"]),
        bar("Internal", snap["internal"]),
        bar("Vault", snap["vault"]),
        bar("Budget", state.resource_budget),
        bar("Funds", state.funds),
        bar("GSJ Cred", state.gsj_credits),
        f"Tier       ADV:{state.adversary_tier} RESP:{state.response_tier}",
        "Trend      " + spark([snap["integrity"], snap["detect"], snap["contain"], snap["service"],
                               snap["exposure"], snap["momentum"], snap["fatigue"],
                               snap["internal"], snap["vault"], state.resource_budget]),
    ]
    return "\n".join(lines)


def render_frame(
    state: IncidentState,
    adversaries: Iterable[AdversaryProfile],
    ansi: bool = True,
    map_width: int = 52,
    map_height: int = 16,
    right_width: int = 52,
) -> str:
    comms_lines = state.comms_buffer[-6:]
    comms_view = "\n".join(comms_lines) if comms_lines else "no comms"
    adv_list = [profile.name for profile in adversaries]
    adv_flavors = ", ".join(profile.flavor for profile in adversaries)
    adv_names = ", ".join(adv_list)
    if ansi:
        adv_names = ANSI_BOLD + ANSI_RED + adv_names + ANSI_RESET
        adv_flavors = ANSI_BOLD + ANSI_RED + adv_flavors + ANSI_RESET
        sog_label = ANSI_BOLD + ANSI_GREEN + "SIDE MISSION: SoG internal defense active" + ANSI_RESET
    else:
        sog_label = "SIDE MISSION: SoG internal defense active"

    map_lines = render_map(
        state,
        width=map_width,
        height=map_height,
        ansi=ansi,
        adversary_names=adv_list,
    ).splitlines()
    dash_lines = render_dashboard(state).splitlines()
    right_lines = [
        "BLACKNET DEFENSE GRID",
        "MAP (S/J/G/R/M agents; V vault; B base; X/Y/Z adversary; P spy; o node; C cache; I intel; * plume; : patrol)",
        "",
    ] + dash_lines + [
        "",
        "ADVERSARIES: " + adv_names,
        "ADV STRATEGY: " + adv_flavors,
        f"DEPLOYMENT: SKY/SEA/CYBER",
        sog_label,
        "",
        "COMMS:",
    ] + comms_view.splitlines()

    if len(right_lines) < map_height:
        right_lines += [""] * (map_height - len(right_lines))
    right_lines = [line[:right_width].ljust(right_width) for line in right_lines[:map_height]]

    combined = []
    for idx in range(map_height):
        left = map_lines[idx] if idx < len(map_lines) else " " * map_width
        right = right_lines[idx] if idx < len(right_lines) else ""
        combined.append(f"{left}  {right}")

    return "\n".join(combined)


def build_ui_payload(
    state: IncidentState,
    adversaries: Iterable[AdversaryProfile],
    map_width: int,
    map_height: int,
    epoch: int,
    wins: int,
    losses: int,
    last_outcome: str,
) -> Dict[str, object]:
    adv_list = [profile.name for profile in adversaries]
    adv_flavors = [profile.flavor for profile in adversaries]
    return {
        "step": state.time_step,
        "epoch": epoch,
        "wins": wins,
        "losses": losses,
        "last_outcome": last_outcome,
        "map": render_map(state, width=map_width, height=map_height, ansi=False, adversary_names=adv_list),
        "dashboard": render_dashboard(state),
        "comms": list(state.comms_buffer),
        "metrics": state.snapshot(),
        "tiers": {"adversary": state.adversary_tier, "response": state.response_tier},
        "budget": state.resource_budget,
        "funds": state.funds,
        "gsj_credits": state.gsj_credits,
        "bases": dict(state.base_integrity),
        "adversaries": [{"name": n, "flavor": f} for n, f in zip(adv_list, adv_flavors)],
        "safe_metrics": {
            "containments": state.containments,
            "recoveries": state.recoveries,
            "blocked": state.blocked,
            "assets_secured": state.assets_secured,
            "intel_recovered": state.intel_recovered,
        },
        "intel_popup": list(state.latest_intel),
        "bank": list(state.bank_entries),
    }


def simulate(
    agents: List[Agent],
    adversaries: List[AdversaryProfile],
    steps: Optional[int] = None,
    seed: Optional[int] = None,
    fps: float = 8.0,
    ansi: bool = True,
    render_console: bool = True,
    step_callback: Optional[Callable[[Dict[str, object]], None]] = None,
    pause_check: Optional[Callable[[], bool]] = None,
    map_override: Optional[Tuple[int, int]] = None,
) -> List[Event]:
    rng = random.Random(seed)
    state = IncidentState()
    events: List[Event] = []
    comms_log = ensure_log_dir()
    last_vault_notice = 0
    last_internal_notice = 0
    last_base_notice: Dict[str, int] = {}
    last_upgrade_notice = 0
    last_rescue_notice = 0
    epoch = 1
    wins = 0
    losses = 0
    last_outcome = "none"

    term = shutil.get_terminal_size(fallback=(160, 50))
    width = max(70, min(150, term.columns - 60))
    height = max(18, min(36, term.lines - 4))
    if map_override is not None:
        width, height = map_override
    right_width = min(60, max(44, term.columns - width - 2))
    base_coords = {
        "base_1": (6, 3),
        "base_2": (width - 7, 4),
        "base_3": (6, height - 4),
    }
    for base_id, coords in base_coords.items():
        state.positions[base_id] = coords
        state.base_integrity[base_id] = 85.0
        last_base_notice[base_id] = 0
    state.positions["vault"] = (width // 2, height // 2)

    adversary_positions: Dict[str, Tuple[int, int]] = {}
    for profile in adversaries:
        adversary_positions[profile.name] = (rng.randint(2, width - 3), rng.randint(2, height - 3))
    win_streak = 0
    spy_positions = {"spy": (width // 2 + 6, height // 2 - 3)}
    # Resource budget ratio scales with adversary count.
    resource_ratio = max(1.0, len(adversaries) / 2.0)

    def reset_campaign(outcome: str) -> None:
        nonlocal epoch, win_streak, last_outcome
        epoch += 1
        win_streak = 0
        last_outcome = outcome
        state.apply(
            {
                "network_integrity": 90.0 - state.network_integrity,
                "detection_confidence": 30.0 - state.detection_confidence,
                "containment_level": 20.0 - state.containment_level,
                "service_availability": 95.0 - state.service_availability,
                "data_exposure_risk": 25.0 - state.data_exposure_risk,
                "adversary_momentum": 40.0 - state.adversary_momentum,
                "fatigue": -state.fatigue,
                "internal_integrity": 88.0 - state.internal_integrity,
                "vault_security": 70.0 - state.vault_security,
            }
        )
        for base_id in state.base_integrity:
            state.base_integrity[base_id] = 85.0
        for profile in adversaries:
            adversary_positions[profile.name] = (rng.randint(2, width - 3), rng.randint(2, height - 3))
        spy_positions["spy"] = (rng.randint(2, width - 3), rng.randint(2, height - 3))
        emit_comms(f"new epoch {epoch} initialized")

    def emit_comms(text: str, alert: bool = False) -> None:
        payload = encode_message(text)
        color = ANSI_RED if alert else ANSI_GREEN
        line = f"{state.time_step:06d} {payload}"
        display_line = f"{state.time_step:06d} {text.upper()}"
        state.comms_buffer.append(display_line)
        state.comms_buffer = state.comms_buffer[-12:]
        if ansi:
            print(color + line + ANSI_RESET)
        else:
            print(line)
        write_comms_log(comms_log, line)

    step = 0
    paused = False
    while True:
        if render_console:
            if msvcrt.kbhit():
                key = msvcrt.getwch()
                if key == " ":
                    paused = not paused
        if pause_check is not None:
            paused = pause_check()

        if paused:
            if ansi:
                print(ANSI_BLACK_BG + ANSI_DIM + ANSI_CLEAR + ANSI_RESET, end="")
                pause_text = "PAUSED - PRESS SPACE TO RESUME"
                print(ANSI_BLACK_BG + ANSI_GREEN + ANSI_BOLD + pause_text + ANSI_RESET)
            else:
                print("PAUSED - PRESS SPACE TO RESUME")
            time.sleep(0.1)
            continue

        step += 1
        state.time_step = step

        threat = generate_threat(state, rng, adversaries)
        if threat:
            impact = threat_impact(threat, rng)
            state.apply(impact)
            events.append(
                Event(
                    t=step,
                    actor=threat.actor,
                    action=f"active-{threat.vector}",
                    impact=impact,
                    notes=f"sev {threat.severity} stealth {threat.stealth}",
                )
            )
            if state.detection_confidence > 70 and rng.random() < 0.45:
                emit_comms(f"decrypted alert {threat.actor} {threat.vector}", alert=True)
                state.blocked += 1
            else:
                emit_comms(f"alert {threat.actor} {threat.vector}", alert=True)

        spy_impact = insider_threat_impact(state, rng)
        if spy_impact:
            state.apply(spy_impact)
            events.append(
                Event(
                    t=step,
                    actor="insider-spy",
                    action="system-disruption",
                    impact=spy_impact,
                    notes="internal sabotage attempt",
                )
            )
            emit_comms("spy disruption detected", alert=True)

        for agent in agents:
            agent._tick()
            actions = agent.act(state, rng)
            for action in actions:
                if action.impact:
                    state.apply(action.impact)
                events.append(action)
                if state.detection_confidence > 65 and rng.random() < 0.35:
                    emit_comms(f"decrypted {action.actor} {action.action}")
                else:
                    emit_comms(f"{action.actor} {action.action}")

        if state.detection_confidence > 70 and state.containment_level > 60:
            impact = {
                "adversary_momentum": -12.0,
                "data_exposure_risk": -6.0,
                "network_integrity": 2.5,
                "internal_integrity": 2.0,
                "vault_security": 2.0,
            }
            state.apply(impact)
            events.append(
                Event(
                    t=step,
                    actor="unit",
                    action="coordinated-neutralization",
                    impact=impact,
                    notes="joint containment + eradication",
                )
            )
            emit_comms("unit coordinated-neutralization")
            state.containments += 1

        if state.internal_integrity < 60 and step - last_internal_notice > 6:
            last_internal_notice = step
            emit_comms("sog lockdown internal defense", alert=True)
            impact = {
                "internal_integrity": 4.0,
                "containment_level": 2.5,
                "service_availability": -1.0,
            }
            state.apply(impact)
            events.append(
                Event(
                    t=step,
                    actor="SoG",
                    action="internal-lockdown",
                    impact=impact,
                    notes="side mission containment",
                )
            )

        if state.vault_security > 90 and step - last_vault_notice > 10:
            last_vault_notice = step
            emit_comms("vault secured treasure protected")
            state.assets_secured += 1

        for base_id in list(state.base_integrity.keys()):
            decay = max(0.0, state.adversary_momentum - 35) * 0.05
            if state.base_integrity[base_id] > 0:
                state.base_integrity[base_id] = clamp(state.base_integrity[base_id] - decay)
            if state.base_integrity[base_id] < 40 and step - last_base_notice[base_id] > 10:
                last_base_notice[base_id] = step
                emit_comms(f"base compromised {base_id}", alert=True)

        if state.model_level > 40 and step - last_upgrade_notice > 18:
            last_upgrade_notice = step
            emit_comms("upgrade protocol applied adaptive defenses")
            state.apply({"detection_confidence": 2.0, "containment_level": 2.0})
            state.recoveries += 1
            state.funds = clamp(state.funds - 5.0, 0.0, 1000.0)
            state.gsj_credits = clamp(state.gsj_credits + 2.0, 0.0, 1000.0)

        if state.internal_integrity > 75 and state.vault_security > 80 and step - last_rescue_notice > 20:
            last_rescue_notice = step
            emit_comms("sog assets secured and restored")
            state.assets_secured += 1
            state.funds = clamp(state.funds + 12.0, 0.0, 1000.0)
            state.gsj_credits = clamp(state.gsj_credits + 4.0, 0.0, 1000.0)

        update_learning(state)
        adjust_tiers(state)
        compute_resource_budget(state)
        state.resource_budget = clamp(state.resource_budget / resource_ratio, 20.0, 140.0)
        # Response tier boosts if budget allows.
        if state.resource_budget > 110:
            state.response_tier = min(3, state.response_tier + 1)
        # Insider pressure slowly ramps up to keep defensive pressure high.
        state.apply({"insider_threat_level": 0.4})
        state.apply({"fatigue": 1.0, "service_availability": -0.35})
        if state.fatigue > 80:
            state.apply({"detection_confidence": -2.5, "containment_level": -2.0})

        ensure_terrain(state, width, height, rng)
        ensure_assets(state, width, height, rng)

        if "snake" not in state.positions:
            state.positions["snake"] = (width // 2 - 4, height // 2)
            state.positions["jester"] = (width // 2 - 1, height // 2 + 1)
            state.positions["ghost"] = (width // 2 + 2, height // 2)
            state.positions["sniper"] = (width // 2 - 6, height // 2 + 2)
            state.positions["heavy_arms"] = (width // 2 + 5, height // 2 - 1)

        move_agents(
            state,
            rng,
            width=width,
            height=height,
            agent_names=["snake", "jester", "ghost", "sniper", "heavy_arms"],
            adversary_positions=adversary_positions,
        )
        for agent_name in ["snake", "jester", "ghost", "sniper", "heavy_arms"]:
            if agent_name not in state.trace and agent_name in state.positions:
                state.trace[agent_name] = [state.positions[agent_name]]

        for adv_name, pos in adversary_positions.items():
            state.positions[adv_name] = pos
            state.trace.setdefault(adv_name, []).append(pos)
            state.trace[adv_name] = state.trace[adv_name][-6:]

        # Treasure cache recovery by any agent.
        agent_positions = {name: pos for name, pos in state.positions.items() if name in ["snake", "jester", "ghost", "sniper", "heavy_arms"]}
        for cache in list(state.cache_points):
            for agent_name, pos in agent_positions.items():
                if abs(cache[0] - pos[0]) + abs(cache[1] - pos[1]) <= 1:
                    state.cache_points.remove(cache)
                    state.assets_secured += 1
                    state.funds = clamp(state.funds + 18.0, 0.0, 1000.0)
                    state.gsj_credits = clamp(state.gsj_credits + 6.0, 0.0, 1000.0)
                    state.bank_entries.append(
                        {
                            "title": f"Treasure Cache ({agent_name})",
                            "detail": f"Recovered at {cache[0]},{cache[1]} on step {state.time_step}",
                            "type": "treasure",
                        }
                    )
                    emit_comms(f"treasure cache recovered by {agent_name}")
                    break

        # Spies drift around internal zones.
        for spy_name, pos in list(spy_positions.items()):
            sx, sy = pos
            dx, dy = rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1), (0, 0)])
            sx = max(1, min(width - 2, sx + dx))
            sy = max(1, min(height - 2, sy + dy))
            spy_positions[spy_name] = (sx, sy)

        for spy_name, pos in spy_positions.items():
            state.positions[spy_name] = pos
            state.trace.setdefault(spy_name, []).append(pos)
            state.trace[spy_name] = state.trace[spy_name][-4:]

        # Spy reveals intel when close; impacts operations.
        spy_pos = spy_positions["spy"]
        for intel in list(state.intel_points):
            if intel not in state.revealed_intel:
                dist = abs(intel[0] - spy_pos[0]) + abs(intel[1] - spy_pos[1])
                if dist <= 2:
                    state.revealed_intel.add(intel)
                    state.intel_recovered += 1
                    state.apply({"detection_confidence": 2.0, "adversary_momentum": -1.5})
                    emit_comms("spy intel recovered")
                    # Generate pseudo high-level intel snippets for 3 adversaries.
                    languages = ["JSON", "YAML", "RUST", "PYTHON", "SQL", "TOML"]
                    lines = []
                    for profile in adversaries:
                        lang = rng.choice(languages)
                        if lang == "JSON":
                            lines.append(f'{{"actor":"{profile.name}","tier":{state.adversary_tier},"vector":"{rng.choice(profile.signatures).vector}"}}')
                        elif lang == "YAML":
                            lines.append(f"{profile.name}:\n  tier: {state.adversary_tier}\n  bias: {profile.pressure_bias:.2f}")
                        elif lang == "RUST":
                            lines.append(f"let {profile.name}_tier: u8 = {state.adversary_tier};")
                        elif lang == "PYTHON":
                            lines.append(f"{profile.name}_pressure = {profile.pressure_bias:.2f}")
                        elif lang == "SQL":
                            lines.append(f"SELECT vector FROM intel WHERE actor='{profile.name}';")
                        else:
                            lines.append(f'{profile.name} = {{ tier = {state.adversary_tier}, bias = {profile.pressure_bias:.2f} }}')
                    state.latest_intel = lines[:3]
                    state.bank_entries.append(
                        {
                            "title": f"Spy Intel #{state.intel_recovered}",
                            "detail": " | ".join(state.latest_intel),
                            "type": "intel",
                        }
                    )

        all_bases_ok = all(value > 50 for value in state.base_integrity.values())
        if state.adversary_momentum < 10 and state.vault_security > 85 and all_bases_ok:
            win_streak += 1
        else:
            win_streak = 0

        if win_streak >= 5:
            wins += 1
            msg = f"{state.time_step:06d} outcome=defenders win epoch={epoch}"
            write_winner_log(msg)
            emit_comms("campaign victory achieved")
            state.apply({"model_level": 2.0})
            reset_campaign("defenders win")

        if state.vault_security < 15 or all(value < 20 for value in state.base_integrity.values()):
            losses += 1
            msg = f"{state.time_step:06d} outcome=defenders overwhelmed epoch={epoch}"
            write_winner_log(msg)
            emit_comms("defense overwhelmed reset", alert=True)
            reset_campaign("defenders overwhelmed")

        write_stats_snapshot(state, epoch, wins, losses, last_outcome)

        if step_callback is not None:
            payload = build_ui_payload(
                state,
                adversaries,
                map_width=width,
                map_height=height,
                epoch=epoch,
                wins=wins,
                losses=losses,
                last_outcome=last_outcome,
            )
            step_callback(payload)

        if render_console:
            if ansi:
                print(ANSI_BLACK_BG + ANSI_DIM + ANSI_CLEAR + ANSI_RESET, end="")
            frame = render_frame(
                state,
                adversaries,
                ansi=ansi,
                map_width=width,
                map_height=height,
                right_width=right_width,
            )
            if ansi:
                print(ANSI_BLACK_BG + ANSI_GREEN + frame + ANSI_RESET)
            else:
                print(frame)
            print("-" * 64)

        if steps is not None and step >= steps:
            outcome = "draw"
            score = (
                (100 - state.adversary_momentum)
                + state.vault_security
                + state.internal_integrity
                + sum(state.base_integrity.values())
            )
            if score >= 260:
                outcome = "defenders win"
                wins += 1
            else:
                outcome = "defenders overwhelmed"
                losses += 1
            msg = f"{state.time_step:06d} outcome={outcome} epoch={epoch}"
            write_winner_log(msg)
            emit_comms(f"campaign concluded {outcome}")
            write_stats_snapshot(state, epoch, wins, losses, outcome)
            if step_callback is not None:
                payload = build_ui_payload(
                    state,
                    adversaries,
                    map_width=width,
                    map_height=height,
                    epoch=epoch,
                    wins=wins,
                    losses=losses,
                    last_outcome=outcome,
                )
                step_callback(payload)
            break

        sleep_time = max(0.0, 1.0 / max(1.0, fps))
        time.sleep(sleep_time)

    return events
