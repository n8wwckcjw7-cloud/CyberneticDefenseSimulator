from __future__ import annotations

from typing import List
import random

from sim_core import Agent, Event, IncidentState


class Snake(Agent):
    def __init__(self) -> None:
        super().__init__(
            name="Snake",
            specialty="threat-hunting",
            skills=[
                "intel-correlation",
                "behavior-analytics",
                "signal-amplification",
                "sog-scan",
            ],
        )

    def act(self, state: IncidentState, rng: random.Random) -> List[Event]:
        events: List[Event] = []

        if self._ready("intel-correlation"):
            impact = {
                "detection_confidence": 6.5 + rng.uniform(0.0, 2.0),
                "adversary_momentum": -3.5,
                "data_exposure_risk": -1.5,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="intel-correlation",
                    impact=impact,
                    notes="cross-site indicators matched",
                )
            )
            self.cooldowns["intel-correlation"] = 2

        if self._ready("behavior-analytics"):
            impact = {
                "detection_confidence": 5.0 + rng.uniform(0.0, 3.0),
                "containment_level": 2.0,
                "adversary_momentum": -2.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="behavior-analytics",
                    impact=impact,
                    notes="anomalous flows flagged",
                )
            )
            self.cooldowns["behavior-analytics"] = 2

        if self._ready("signal-amplification") and state.detection_confidence < 60:
            impact = {
                "detection_confidence": 7.0,
                "service_availability": -1.0,
                "fatigue": 1.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="signal-amplification",
                    impact=impact,
                    notes="sensor sweep + log burst",
                )
            )
            self.cooldowns["signal-amplification"] = 3

        if self._ready("sog-scan") and state.internal_integrity < 75:
            impact = {
                "internal_integrity": 4.5 + rng.uniform(0.0, 2.0),
                "detection_confidence": 2.5,
                "adversary_momentum": -1.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="sog-scan",
                    impact=impact,
                    notes="internal structure scan + isolate",
                )
            )
            self.cooldowns["sog-scan"] = 3

        return events
