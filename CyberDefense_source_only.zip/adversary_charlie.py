from __future__ import annotations

from sim_core import AdversaryProfile, ThreatSignature


def profile() -> AdversaryProfile:
    return AdversaryProfile(
        name="adversary_charlie",
        flavor="opportunistic persistence",
        pressure_bias=0.5,
        signatures=[
            ThreatSignature("cloud-misconfig", 16, 20, 20, 20),
            ThreatSignature("credential-stuffing", 18, 18, 16, 16),
            ThreatSignature("shadow-admin", 21, 24, 12, 28),
        ],
    )
