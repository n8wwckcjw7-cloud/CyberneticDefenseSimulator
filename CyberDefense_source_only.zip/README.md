# Cyber Defense Simulation (Safe, Non‑Violent)

A fullscreen cyber‑defense simulation with ASCII terrain, unit coordination, and live telemetry.  
This project is **non‑violent** and focuses on safe cyber‑defense concepts only.

## Features
- Fullscreen UI with dense ASCII map and telemetry
- Safe adversary profiles (generic)
- Spy intel, caches, and internal defense mechanics
- Separate stats window (optional)
- Donation popup with QR (optional, local only)

## Requirements
- Python 3.11+ (tested with 3.12)
- `pygame` (GUI)
- `pyglet` (installed; optional)
- `qrcode` and `Pillow` (donation QR rendering)

Install dependencies:
```powershell
pip install -r requirements.txt
```

## Run
GUI (default):
```powershell
python .\main.py
```

CLI (console only):
```powershell
python .\main.py --cli
```

## Controls
- `Space`: pause/resume, or dismiss popups
- `Enter`: dismiss popups
- `Esc`: exit fullscreen GUI

## Notes
- This is a **simulation** only; it does not implement harmful or weaponized behavior.

