from __future__ import annotations

from typing import List
import random

from sim_core import Agent, Event, IncidentState


class HeavyArms(Agent):
    def __init__(self) -> None:
        super().__init__(
            name="HeavyArms",
            specialty="rapid-reinforcement",
            skills=[
                "bulk-isolation",
                "stability-push",
                "rebuild-surge",
            ],
        )

    def act(self, state: IncidentState, rng: random.Random) -> List[Event]:
        events: List[Event] = []

        if self._ready("bulk-isolation") and state.adversary_momentum > 35:
            impact = {
                "containment_level": 5.0 + rng.uniform(0.0, 2.0),
                "service_availability": -1.5,
                "data_exposure_risk": -2.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="bulk-isolation",
                    impact=impact,
                    notes="broad isolation wave",
                )
            )
            self.cooldowns["bulk-isolation"] = 3

        if self._ready("stability-push") and state.service_availability < 85:
            impact = {
                "service_availability": 4.0 + rng.uniform(0.0, 1.5),
                "network_integrity": 2.0,
                "fatigue": 1.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="stability-push",
                    impact=impact,
                    notes="service stabilization burst",
                )
            )
            self.cooldowns["stability-push"] = 3

        if self._ready("rebuild-surge") and state.network_integrity < 80:
            impact = {
                "network_integrity": 4.5,
                "internal_integrity": 2.5,
                "fatigue": 1.2,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="rebuild-surge",
                    impact=impact,
                    notes="infrastructure rebuilt",
                )
            )
            self.cooldowns["rebuild-surge"] = 4

        return events
