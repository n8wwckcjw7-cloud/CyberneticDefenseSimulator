from __future__ import annotations

from typing import List
import random

from sim_core import Agent, Event, IncidentState


class Sniper(Agent):
    def __init__(self) -> None:
        super().__init__(
            name="Sniper",
            specialty="precision-response",
            skills=[
                "pinpoint-triage",
                "signal-silence",
                "micro-containment",
            ],
        )

    def act(self, state: IncidentState, rng: random.Random) -> List[Event]:
        events: List[Event] = []

        if self._ready("pinpoint-triage") and state.data_exposure_risk > 25:
            impact = {
                "data_exposure_risk": -3.5 - rng.uniform(0.0, 1.5),
                "detection_confidence": 2.0,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="pinpoint-triage",
                    impact=impact,
                    notes="high-risk nodes isolated",
                )
            )
            self.cooldowns["pinpoint-triage"] = 2

        if self._ready("signal-silence") and state.adversary_momentum > 30:
            impact = {
                "adversary_momentum": -4.0,
                "containment_level": 2.5,
                "service_availability": -0.5,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="signal-silence",
                    impact=impact,
                    notes="noisy channels suppressed",
                )
            )
            self.cooldowns["signal-silence"] = 3

        if self._ready("micro-containment") and state.containment_level < 60:
            impact = {
                "containment_level": 4.5 + rng.uniform(0.0, 1.0),
                "internal_integrity": 1.5,
                "fatigue": 0.6,
            }
            events.append(
                Event(
                    t=state.time_step,
                    actor=self.name,
                    action="micro-containment",
                    impact=impact,
                    notes="localized containment locks",
                )
            )
            self.cooldowns["micro-containment"] = 3

        return events
