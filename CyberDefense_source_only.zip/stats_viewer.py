from __future__ import annotations

import json
import os
import time


ANSI_CLEAR = "\x1b[2J\x1b[H"
ANSI_RESET = "\x1b[0m"
ANSI_GREEN = "\x1b[32m"
ANSI_RED = "\x1b[31m"
ANSI_BOLD = "\x1b[1m"


def render_bar(label: str, value: float, width: int = 28) -> str:
    blocks = int(value / (100 / width))
    fill = "|" * blocks
    rest = "/" * (width - blocks)
    return f"{label:12} [{fill}{rest}] {value:5.1f}"


def render_stats(data: dict) -> str:
    bases = data.get("bases", {})
    lines = [
        "STATS WINDOW",
        f"Epoch {data.get('epoch', 0):02d}  Step {data.get('step', 0):06d}",
        render_bar("Integrity", data.get("integrity", 0.0)),
        render_bar("Detect", data.get("detect", 0.0)),
        render_bar("Contain", data.get("contain", 0.0)),
        render_bar("Service", data.get("service", 0.0)),
        render_bar("Exposure", data.get("exposure", 0.0)),
        render_bar("Momentum", data.get("momentum", 0.0)),
        render_bar("Fatigue", data.get("fatigue", 0.0)),
        render_bar("Internal", data.get("internal", 0.0)),
        render_bar("Vault", data.get("vault", 0.0)),
        render_bar("Model", data.get("model", 0.0)),
        render_bar("Funds", data.get("funds", 0.0)),
        render_bar("GSJ Cred", data.get("gsj_credits", 0.0)),
        "",
        "SAFE METRICS",
        f"Containments: {data.get('containments', 0)}",
        f"Recoveries:   {data.get('recoveries', 0)}",
        f"Blocked:      {data.get('blocked', 0)}",
        f"Assets Sec:   {data.get('assets_secured', 0)}",
        "",
        "BASES",
    ]
    for key, value in bases.items():
        lines.append(render_bar(key, value))
    lines.append("")
    lines.append("LAST OUTCOME: " + str(data.get("last_outcome", "none")))
    lines.append("WINS: " + str(data.get("wins", 0)) + "  LOSSES: " + str(data.get("losses", 0)))
    return "\n".join(lines)


def main() -> None:
    stats_path = os.path.join(os.getcwd(), "logs", "stats.json")
    while True:
        if os.path.exists(stats_path):
            try:
                with open(stats_path, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                view = render_stats(data)
                print(ANSI_CLEAR + ANSI_BOLD + ANSI_GREEN + view + ANSI_RESET)
            except Exception:
                pass
        time.sleep(0.2)


if __name__ == "__main__":
    main()
